def revStr(st):
	return st[::-1]

def addstr(st1,st2):
	return st1 + ":" + st2 
